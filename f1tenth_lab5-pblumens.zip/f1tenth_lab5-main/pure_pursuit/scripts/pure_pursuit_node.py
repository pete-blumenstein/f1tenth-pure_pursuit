#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

import numpy as np
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive
# TODO CHECK: include needed ROS msg type headers and libraries
from geometry_msgs.msg import PoseStamped, PointStamped, Pose
from nav_msgs.msg import Odometry, Path
from tf.transformations import quaternion_matrix

class PurePursuit(Node):
    """ 
    Implement Pure Pursuit on the car
    This is just a template, you are free to implement your own node!
    """
    def __init__(self):
        super().__init__('pure_pursuit_node')
        # TODO: create ROS subscribers and publishers
        lidarscan_topic = '/scan'
        drive_topic = '/drive'

        self.subscription_scan = self.create_subscription(
            LaserScan,
            lidarscan_topic,
            self.scan_callback,
            10)
        self.subscription_scan

        self.drive_pub = self.create_publisher(
            AckermannDriveStamped,
            drive_topic,
            10)
        
        
        self.Ld = 0.5 # Lookahead distance (meters)
        self.waypoints = np.genfromtxt('',delimiter=',') # EDIT ME - add file path
        self.wp_idx = 0

    def pose_callback(self, pose_msg):
        pass
        x_curr = pose_msg.pose.pose.position.x
        y_curr = pose_msg.pose.pose.position.y
        quaternion = [pose_msg.pose.pose.orientation.x, pose_msg.pose.pose.orientation.y, pose_msg.pose.pose.orientation.z, pose_msg.pose.pose.orientation.w]
        rot_matrix = quaternion_matrix(quaternion)[0:3, 0:3]

        # TODO: find the current waypoint to track using methods mentioned in lecture
        dist = (self.waypoints[:,0]-x_curr)**2+(self.waypoints[:,1]-y_curr)**2
        closest_idx = np.argmin(dist)
        found = 0 # Flag turned true if a future waypoint is found. If still false => wrapped to beginning of waypoint loop
        for i in range(closest_idx,self.waypoints.shape[0]-1):
            if dist[i] > self.Ld:
                self.wp_idx = i # Index of first waypoint outside the lookahead distance
                found = 1
                break

        if found == 0: # Implies last waypoint in list is too close to vehicle. Restart at the beginning of the list
            for i in range(0,closest_idx):
                if dist[i] > self.Ld:
                    self.wp_idx = i
                    break

        # TODO: transform goal point to vehicle frame of reference
        target_wp = self.waypoints[self.wp_idx]
        target_world = target_wp - [x_curr,y_curr]
        target_world = np.append(target_world, 0)
        target_vehicle = np.matmul(np.linalg.inv(rot_matrix), target_world)

        # TODO: calculate curvature/steering angle
        angle = 2*target_vehicle[1]/self.Ld**2

        # TODO: publish drive message, don't forget to limit the steering angle.
        steering_angle = np.clip(angle,-0.35,0.35) # ~ +/-40 degrees
        # Adjust speed and lookahead distance based on the steering angle
        abs_angle = np.abs(steering_angle)
        if abs_angle >= 0.28:
            speed = 0.5
            self.Ld = 0.25
        elif abs_angle >= 0.15:
            speed = 0.75
            self.lookahead = 0.5
        else:
            speed = 1
            self.lookahead = 0.75


        drive = AckermannDrive(speed = speed, steering_angle = steering_angle)
        drive_msg = AckermannDriveStamped(drive = drive)
        self.drive_pub.publish(drive_msg)

def main(args=None):
    rclpy.init(args=args)
    print("PurePursuit Initialized")
    pure_pursuit_node = PurePursuit()
    rclpy.spin(pure_pursuit_node)

    pure_pursuit_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
